import http.server
import json
import MySQLdb

class Handler(http.server.BaseHTTPRequestHandler):
    """HTTP 요청을 처리하는 클래스"""
    def do_GET(self):

        """요청 메시지의 메서드가 GET 일 때 호출되어, 응답 메시지를 전송한다."""
        # 응답 메시지의 상태 코드를 전송한다

        if self.path.endswith('favicon.ico'):
            return

        if self.path.endswith('php'):
            return

        if self.path.endswith('index'):
            return

        if self.path.endswith('txt'):
            return
        #print(self.path)
        #print(len(self.path))
        if len(self.path) > 4:
            if self.path[4] != '&':
                return

            if self.path[4] == '&':

                self.send_response(200)

                # 응답 메시지의 헤더를 전송한다
                self.send_header('Content-type', 'text/plain; charset=utf-8')
                self.end_headers()

                # print(message_path)

                # con = MySQLdb.connect("localhost", "eatcoder", "eatcoder1111!", "testdb")
                con = MySQLdb.connect("localhost", "root", "Eatcoder", "eatcoderDB")
                cur = con.cursor(MySQLdb.cursors.DictCursor)

                key = self.path.replace("/", "")

                keyArr = key.split('&')
                train_no = ''
                line_no = ''
                section_no = ''

                # print(keyArr)
                if len(keyArr) == 2:
                    line_no = keyArr[0]
                    if len(keyArr[1]) == 4:
                        train_no = keyArr[1]
                    elif len(keyArr[1]) == 7:
                        section_no = keyArr[1]

                # print("line_no", line_no)
                # print("train_no", train_no)
                # print("section_no", section_no)

                if line_no != '' and train_no != '':
                    print("query start CONGESTION")
                    query = '''
                                    select 
                                        RIGHT(SECTION_NO ,3) AS SECTION_NO,
                                        CONGESTION ,
                                        VACANCY
                                    FROM SECTION_CONGESTION 
                                    WHERE TRAIN_NO={} AND LINE_NO={} ORDER BY SECTION_NO'''.format(train_no, line_no)
                    # print(query)
                    cur.execute(query)
                    data = cur.fetchall()
                    dataList = list(data)

                    for i in range(0, len(dataList)):
                        dataList[i] = json.dumps(dataList[i])

                    dataStr = str(dataList)
                    dataJson = dataStr.replace("'", "")
                    dataJson = '{"list":' + dataJson + '}'
                    print(dataJson)

                    self.wfile.write(dataJson.encode())

                elif line_no != '' and section_no != '':
                    print("query start JPG")
                    query = '''
                                    select 
                                        CONGESTION, IMAGE_NM
                                    FROM SECTION_CONGESTION
                                    WHERE LINE_NO={} AND SECTION_NO={}
                                    '''.format(line_no, section_no)
                    #print(query)
                    cur.execute(query)
                    data = cur.fetchall()
                    directory_level = data[0]['CONGESTION']
                    image_nm = data[0]['IMAGE_NM']
                    files = open('metro/LEVEL' + str(directory_level) + '/' + image_nm, "rb")
                    image_data = files.read()

                    self.wfile.write(image_data)


        else:
            return




    def do_POST(self):

        if self.path.endswith('wst'):
            return

        if len(self.path) > 4:
            if self.path[4] != '&':
                return
        else:
            return



# 요청받을 주소 (요청을 감시할 주소)
address = ('192.168.0.11', 8080)

# 요청 대기하기
listener = http.server.HTTPServer(address, Handler)
print('http://{address[0]}:{address[1]} 주소에서 요청 대기중...')
listener.serve_forever()
