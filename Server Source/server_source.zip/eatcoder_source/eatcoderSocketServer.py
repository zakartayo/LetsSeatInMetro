import threading
import socketserver
import socket
import sys
import retrain_run_inference

lock = threading.Lock()
BUF = 1024
RETRAIN = retrain_run_inference

save_directory = "model/"
train_directory = "metro/"


def print_delimiter():
    print("=" * 20)

class UserManager:

    def __init__(self):
        self.users = {}

    def addUser(self, conn, addr):
        if addr in self.users:
            return None

        lock.acquire()  # 스레드 동기화를 막기위한 락
        self.users[addr] = conn
        lock.release()  # 업데이트 후 락 해제
        print("num:",len(self.users))

        return addr

    def removeUser(self, addr):
        if addr not in self.users:
            return

        lock.acquire()
        del self.users[addr]
        lock.release()
        print('--- client 수 [%d]' % len(self.users))


    def sendMessageToOneAddr(self, addr ,msg):
        conn = self.users[addr]
        conn.send(msg.encode())


class ThreadedTCPRequestHandler(socketserver.BaseRequestHandler):
    raspBPI = UserManager()
    def handle(self):
        #cur_thread = threading.current_thread()
        #print("{} was started for {}".format(cur_thread.getName, self.client_address[0]))

        print("ip :", self.client_address[0])

        try:
            self.raspBPI.addUser(self.request, self.client_address[0])
            self.recv_data = self.request.recv(BUF).decode().strip()

            while self.recv_data:

                END = "FALSE"

                # image 받기
                if self.recv_data == "SEND_IMAGE":
                    print("image downloading...")
                    # SNMI 입력 받은 후 SNMI_OK 전송
                    self.request.send("IMAGE_OK".encode())

                    # file_size 받기
                    file_size = self.request.recv(BUF).decode()

                    # file_size OK
                    if int(file_size) > 0:
                        print("size:{}".format(file_size));
                        self.request.send("SIZE_TRUE".encode())
                        # 이름 입력 대기
                        image_nm = self.request.recv(BUF).decode()
                        print("image nm : {}".format(image_nm))
                        image = open(save_directory + image_nm, "wb")

                        # 이름 입력 OK 전송
                        self.request.send("IMAGE_NM_OK".encode())
                        image_data = self.request.recv(BUF)
                        partPlusSize = 0
                        while image_data:
                            imageDataPartLength = len(image_data)
                            partPlusSize += imageDataPartLength
                            # print(partPlusSize)
                            image.write(image_data)

                            # fies_size 만큼 while문 돌기
                            if partPlusSize == int(file_size):
                                print("end...")
                                break
                            image_data = self.request.recv(BUF)

                        print("SUCESS")
                        END = "TRUE"
                        image.close()

                        print_delimiter()

                        # 딥러닝
                        answer = RETRAIN.run_inference_on_image(image_nm)
                        print("result :", answer)

                        print_delimiter()

                        yolo_value = image_nm + ':' + answer

                        ####################################################################
                        self.raspBPI.sendMessageToOneAddr('192.168.0.1', yolo_value)
                        #######################  YOLO _ CLIENT #############################

                    else:
                        self.request.send("SIZE_FALSE".encode())
                        print("FILE_SIZE RECV FAIL")

                # image down loading end
                if END == "FALSE":
                    self.request.sendall(self.recv_data.upper().encode())
                elif END == "TRUE":
                    self.request.send("IMAGE DOWN END".encode())

                self.recv_data = self.request.recv(BUF).decode().strip()
                print_delimiter()

        except Exception as e:
            print("")

        self.request.close()
        self.raspBPI.removeUser(self.client_address[0])

        print_delimiter()




class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass


if __name__ == "__main__":

    HOST, PORT = '192.168.0.11', 20000
    #HOST, PORT = socket.gethostname(), 20000

    try:
        server = ThreadedTCPServer((socket.gethostbyname(HOST), PORT), ThreadedTCPRequestHandler)

    except socket.error as msg:
        print("Bind failed. closing..")
        print("ERROR CODE : {} \nERROR MESSAGE: {}".format(msg[0], msg[1]))
        sys.exit()

    print("Socket bound on {}".format(PORT))
    ip, port = server.server_address

    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()

    server.serve_forever()

    server.shoutdown()
    server.server_close()
