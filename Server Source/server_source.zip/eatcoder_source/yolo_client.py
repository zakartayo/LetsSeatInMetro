import socket
import sys
import darknetpy as dk
import MySQLdb
import shutil
import threading

save_directory = "model/"
train_directory = "metro/"


darknetLoadResult = dk.darknet_load()

net = darknetLoadResult[0]
meta = darknetLoadResult[1]


BUF = 1024
HOST, PORT = '113.198.84.121', 20000

def print_delimiter():
    print("=" * 20)

def imageLoadThread(url, r):
    dk.img_load(url,r)

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))

except socket.error as msg:
    print("Failed to create socket. ERROR CODE : {} \n ERROR MESSAGE: {}"
          .format(msg[0], msg[1]))
    sys.exit(0)

print("SOCKET CREATED")

while True:
    try:
        try:
            received = sock.recv(BUF).decode()
            print("Received :   {}".format(received))
            recv_arr = received.split(':')

            if len(recv_arr) == 2:
                image_nm = recv_arr[0]
                answer = recv_arr[1]

                key = image_nm.replace(".jpg", "")

                table = "SECTION_CONGESTION"
                congestion = answer.replace("level", "")

                keyArr = key.split("_")
                line_no = keyArr[0]
                section_no = keyArr[1]

                print_delimiter()

                print("Line_NO :: ", line_no)
                print("Section_NO :: ", section_no)
                print("Congestion :: ", congestion)

                print_delimiter()

                vacancy = 0
                if congestion == '1' or congestion == '2':
                    dir = "model/"
                    print("detect Path and image name : ", dir + image_nm)
                    detectR = dk.detect(net, meta, (dir + image_nm).encode("ascii"))
                    personNum = len(detectR)
                    print("person_num :: ", personNum)
                    vacancy = 42 - personNum
                    print("vacancy :: ", vacancy)

                    # for list1 in detectR:
                    #     print(list1[0], list1[1])

                    dk.img_load(dir + image_nm, detectR)
                    # t = threading.Thread(target=imageLoadThread, args=(dir+image_nm,detectR))
                    # t.start()

                else:
                    vacancy = 0

                shutil.move(save_directory + image_nm, train_directory + answer.upper())
                # mysql과 연동

                con = MySQLdb.connect("localhost", "root", "Eatcoder", "eatcoderDB")
                cur = con.cursor(MySQLdb.cursors.DictCursor)
                image = "'" + image_nm + "'"

                query = 'UPDATE {} SET CONGESTION={}, VACANCY={}, IMAGE_NM={} WHERE LINE_NO={} AND SECTION_NO={}'.format(
                    table, congestion, vacancy, image, line_no, section_no, )
                # print(query)
                print(query)
                cur.execute(query)
                con.commit()

            else:
                break



        finally:
            print("")

    except KeyboardInterrupt as e:
        print(e)
        data = ":/quit"

sock.close()
