import socket
import sys
import os 
import time
import picamera

BUF = 1024
ROOT_PATH="./"
os.chdir(ROOT_PATH)
HOST, PORT = '220.67.228.16', 20000

camera = picamera.PiCamera()

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))
 
except socket.error as msg:
    print("Failed to create socket. ERROR CODE : {} \n ERROR MESSAGE: {}"
          .format(msg[0], msg[1]))
    sys.exit(0)
    
print("SOCKET CREATED") 

while True:
    try:
        data = 'SEND_IMAGE'
 
        if data == ":/quit" or not data:
            sock.close()
            break
        try:
            sock.sendall(data.encode())
            received = sock.recv(BUF).decode()
            print("received : {}".format(received))
            
            line_no = '002'
            section_no = '2301002'
            ##section_no = section_no+input("")
            input("")
            cur_time = time.ctime()
            hour = (cur_time.split(' ')[4]).split(':')[0]
            minute = (cur_time.split(' ')[4]).split(':')[1]
            second = (cur_time.split(' ')[4]).split(':')[2]
 
            if received == "IMAGE_OK":
                file_nm = line_no+"_"+section_no+"_"+hour+minute+second+".jpg"
                
                print(file_nm)
                camera.capture(file_nm)
                
                print(ROOT_PATH+file_nm)
                file_size = os.path.getsize(ROOT_PATH+file_nm)
                print("size : {}".format(file_size))
                    #file_size send
                sock.send(str(file_size).encode())
                gubun = sock.recv(BUF).decode()
                if gubun == "SIZE_TRUE":
                    image = open(file_nm,"rb")
                    image_nm = file_nm
                    image_data = image.read(BUF)
                    sock.send(image_nm.encode())
                    image_ok = sock.recv(BUF).decode()
                    print("IMAGE OK  ? {}".format(image_ok) )
                    if image_ok == "IMAGE_NM_OK":
                        sock.send(image_data)
                        while image_data:
                            image_data=image.read(BUF)
                            sock.send(image_data)
                        image.close()
                        
                        print(sock.recv(BUF).decode())
                        
                elif gubun == "SIZE_FALSE":
                    image.close()
                
        finally:
            print("Send :       {}".format(data))
            print("Received :   {}".format(received))
 
    except KeyboardInterrupt as e:
        print(e)
        data = ":/quit"
    os.remove(file_nm)
sock.close()
